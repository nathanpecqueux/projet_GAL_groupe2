<!DOCTYPE html>
<html>
<head>
    <?php $startFiles = getStartFiles(); ?>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <script type="text/javascript">
        var upageSettings = <?php echo getConfigObject(); ?>;
    </script>

    <link rel='stylesheet' href="<?php echo $startFiles['bootstrap']; ?>" />
    <link rel='stylesheet' href="<?php echo $startFiles['template']; ?>" />
    <link rel='stylesheet' href="<?php echo $startFiles['template.ie']; ?>" />

    <script type="text/javascript" src="<?php echo $startFiles['editor']; ?>"></script>
    <script type="text/javascript" src="<?php echo $startFiles['editor-utility']; ?>"></script>
    <script type="text/javascript" src="<?php echo $startFiles['editor-uploader']; ?>"></script>
    <script type="text/javascript" src="<?php echo $startFiles['loader']; ?>"></script>

    <style type="text/css">
        body {
            background: none transparent;
        }

        body > [data-thumbnail] { /* hide all sections */
            display: none !important;
        }
    </style>

</head>
<body>
    <?php echo UpageSectionsManager::getSectionsContent(); ?>
</body>
</html>