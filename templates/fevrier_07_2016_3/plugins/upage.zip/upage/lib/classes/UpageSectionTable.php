<?php

class UpageSectionTable extends JTable
{
    public function __construct($db)
    {
        parent::__construct('#__upage_sections', 'id', $db);
    }
}