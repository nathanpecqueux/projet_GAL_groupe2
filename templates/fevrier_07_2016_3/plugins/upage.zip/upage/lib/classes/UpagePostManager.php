<?php

include_once 'UpageHelper.php';
include_once 'UpageSectionsManager.php';
include_once 'UpageSectionTable.php';

class UpagePostManager {
    public function __construct() {}

    public function execute($data)
    {
        if ($this->_userAuthorized($data)) {
            echo $this->{$data['action']}($data);
        } else {
            echo "Session error";
        }
    }

    private function _userAuthorized($data)
    {
        // checking user privileges
        $user = JFactory::getUser();
        $session = JFactory::getSession();
        if (!isset($data['frontend']) && false == getenv('THEMLER_MANIFEST_STORAGE') &&
            !(1 !== (integer)$user->guest && 'active' === $session->getState()))
            return false;
        return true;
    }

    public function uploadImage($data) {

        jimport('joomla.filesystem.file');

        $params = JComponentHelper::getParams('com_media');
        $imagesDirFromParams = $params->get('file_path', 'images');
        $imagesFolder = JPATH_ROOT . '/' . $imagesDirFromParams;
        $upageContentFolder = JPath::clean(implode('/', array($imagesFolder, 'upage-content')));
        $file = $_FILES['async-upload'];

        $type = exif_imagetype($file['tmp_name']);
        switch($type)
        {
            case IMAGETYPE_GIF:
                $ext = 'gif';
                break;
            case IMAGETYPE_JPEG:
                $ext = 'jpg';
                break;
            case IMAGETYPE_PNG :
                $ext = 'png';
                break;
            case IMAGETYPE_BMP :
                $ext = 'bmp';
                break;
            default:
                $ext = 'jpg';
        }

        do {
            $name = md5(microtime() . rand(0, 9999));
            $file['filepath'] = $upageContentFolder . '/' . $name . '.' . $ext;
        } while (file_exists($file['filepath']));

        $objectFile = new JObject($file);
        if (!JFile::upload($objectFile->tmp_name, $objectFile->filepath))
        {
            // Error in upload
            JError::raiseWarning(100, JText::_('Unable to upload file'));//COM_MEDIA_ERROR_UNABLE_TO_UPLOAD_FILE
            return false;
        }
        $imagesUrl = str_replace(JPATH_ROOT, dirname(dirname(dirname(dirname(dirname(JUri::current()))))), $file['filepath']);
        $imagesUrl = str_replace('\\', '/',$imagesUrl);
        return $this->_response(array(
            'status' => 'done',
            'upload_id' => '',
            'image_url' => $imagesUrl
        ));
    }

    public function uploadSections($data)
    {
        if (!isset($data['sections']) || !is_array($data['sections'])) {
            return array(
                'status' => 'error',
                'message' => 'sections parameter missing',
            );
        }

        $result = array();

        $sections = $data['sections'];
        foreach($sections as $section) {
            $html = $section['html'];
            $name = isset($section['name']) ? $section['name'] : 'Section';
            $mediaId = isset($section['mediaId']) ? $section['mediaId'] : 0;
            $thumbnailUrl = isset($section['thumbnail']) && is_array($section['thumbnail']) ? $section['thumbnail']['url'] : '';

            $db = JFactory::getDBO();
            if ($mediaId) {
                // update section
                $query = $db->getQuery(true);
                $query->update('#__upage_sections');
                $query->set($db->quoteName('title') . '=' . $db->quote($name));
                $query->set($db->quoteName('content') . '=' . $db->quote($html));
                $query->set($db->quoteName('image') . '=' . $db->quote($thumbnailUrl));
                $query->where('id=' . $query->escape($mediaId));
                $db->setQuery($query);
                $db->query();
            }  else {
                // add section
                $row = new UpageSectionTable($db);
                $row->title = $name;
                $row->content = $html;
                $row->image = $thumbnailUrl;
                if (!$row->check())
                    return array(
                        'status' => 'error',
                        'message' => $row->getError(),
                    );
                if (!$row->store())
                    return array(
                        'status' => 'error',
                        'message' => $row->getError(),
                    );
                $mediaId = $row->id;
            }
            $result[] = array(
                'section_id' => $mediaId
            );
        }
        return $this->_response(array(
            'result' => 'done',
            'data' => $result,
        ));
    }

    public function updatePost($data)
    {
        if (!isset($data['id']) || !isset($data['content'])) {
            return array(
                'status' => 'error',
                'message' => 'post parameter missing',
            );
        }

        $postId = $data['id'];
        $shortcodes = $data['content'];

        $content = UpagePostManager::getArticleContent($postId);
        if (null !== $content) {
            $newContent = $this->_generatePostWithShortcodes($content, $shortcodes);
            UpagePostManager::setArticleContent($newContent, $postId);
        }

        return $this->_response(array(
            'result' => 'done',
        ));
    }

    private function _generatePostWithShortcodes($content, $shortcodes)
    {
        $old = $this->_splitContentBySection($content);
        $new = $this->_splitContentBySection($shortcodes);
        $new = array_filter($new, create_function('$a', 'return $a["type"] === "section";'));

        $presents_ids = array();
        foreach($new as $part) {
            $presents_ids[$part['id']] = true;
        }

        $blocks = array();
        $last_id = 'start';
        foreach($old as $part) {
            if ($part['type'] !== 'section') {
                $blocks[$last_id][] = $part;
            } if (isset($part['id']) && isset($presents_ids[$part['id']])) {
                $last_id = $part['id'];
                $blocks[$last_id] = array($part);
            }
        }

        $result = '';
        foreach($new as $part) {
            $id = $part['id'];
            if (!isset($blocks[$id])) {
                // it's a new section
                $result .= "[upage_section id=$id]\n";
            } else {
                foreach ($blocks[$id] as $old_part) {
                    if ($old_part['type'] !== 'section') {
                        $result .= $old_part['text'];
                    } else if ($id !== 'start') {
                        $result .= "[upage_section id=$id]";
                    }
                }
            }
        }
        return $result;
    }

    private function _splitContentBySection($content)
    {
        require_once JPATH_PLUGINS . '/content/themlercontent/lib/Shortcodes.php';
        ThemeColumns::saveOriginalShortcodes(array(
            "#^upage_section$#" => 'UpagePostManager::sectionPlaceholder'
        ));
        $content = ShortcodesUtility::doShortcode($content);
        ThemeColumns::restoreOriginalShortcodes();

        $parts = preg_split('#(%SECTION\d*%)#', $content, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY);
        $result = array(
            array(
                'type' => 'section',
                'id' => 'start',
            )
        );
        foreach($parts as $part) {
            if (preg_match('#^%SECTION(\d*)%$#', $part, $m)) {
                $result[] = array(
                    'type' => 'section',
                    'id' => $m[1],
                );
            } else {
                $result[] = array(
                    'type' => 'text',
                    'text' => $part,
                );
            }
        }
        return $result;
    }

    public static function sectionPlaceholder($atts, $content = '') {
        $atts = ShortcodesUtility::atts(array(
            'id' => ''
        ), $atts);

        $id = $atts['id'];
        return "%SECTION$id%";
    }

    public static function getArticleContent($id)
    {
        if ('' == $id)
            return '';
        $db = JFactory::getDBO();
        $query = 'SELECT * FROM #__content'
            . ' WHERE id = ' . intval($id)
            . ' ORDER BY id';
        $db->setQuery($query, 0, 0);
        $rows = $db->loadAssocList();
        if ($db->getErrorNum())
            return null;
        if (count($rows) < 1)
            return null;

        $result = JTable::getInstance('content');
        $result->bind($rows[0]);
        return $result->introtext . '[[DELIMITER]]' . $result->fulltext;
    }

    public static function setArticleContent($content, $id)
    {
        if ('' == $id)
            return;
        $parts = explode('[[DELIMITER]]', $content);
        $intro = $parts[0];
        $full = count($parts) > 1 ? $parts[1] : '';

        $db = JFactory::getDBO();
        $query = $db->getQuery(true);
        $query->update('#__content');
        $query->set($db->quoteName('introtext') . '=' . $db->quote($intro));
        $query->set($db->quoteName('fulltext') . '=' . $db->quote($full));
        $query->where('id=' . $query->escape($id));
        $db->setQuery($query);
        $db->query();
    }

    private function _response($result)
    {
        if (is_string($result)) {
            $result = array('result' => $result);
        }
        return json_encode($result);
    }
}